//
//  Growth_SDK_iOS.h
//  Growth SDK iOS
//
//  Created by B0207530 on 09/08/24.
//

#import <Foundation/Foundation.h>

//! Project version number for Growth_SDK_iOS.
FOUNDATION_EXPORT double Growth_SDK_iOSVersionNumber;

//! Project version string for Growth_SDK_iOS.
FOUNDATION_EXPORT const unsigned char Growth_SDK_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Growth_SDK_iOS/PublicHeader.h>


